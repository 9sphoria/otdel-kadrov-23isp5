<?php
session_start();
if (!isset($_SESSION["user_id"])) { header("Location: index.php"); exit; }

$dsn = "mysql:host=localhost;dbname=hr_agency;charset=utf8mb4";
$pdo = new PDO($dsn, "root", "", [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);

if ($_SERVER["REQUEST_METHOD"]==="POST" && isset($_POST["add"])) {
  $stmt=$pdo->prepare("INSERT INTO resumes(seeker_id,desired_position,experience_years,salary_expectation,about) VALUES (?,?,?,?,?)");
  $stmt->execute([$_POST["seeker_id"],$_POST["desired_position"],$_POST["experience_years"],$_POST["salary_expectation"],$_POST["about"]]);
  header("Location: resumes.php"); exit;
}
if (isset($_GET["delete"])) {
  $pdo->prepare("DELETE FROM resumes WHERE id=?")->execute([$_GET["delete"]]);
  header("Location: resumes.php"); exit;
}

$seekers=$pdo->query("SELECT id,fio FROM seekers ORDER BY fio")->fetchAll(PDO::FETCH_ASSOC);
$resumes=$pdo->query("SELECT r.id,s.fio,r.desired_position,r.experience_years,r.salary_expectation,r.about FROM resumes r JOIN seekers s ON r.seeker_id=s.id ORDER BY r.id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8"><title>Резюме</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>Модуль "Резюме"</header>
<nav>
  <a href="home.php">Главная</a>
  <a href="seekers.php">Соискатели</a>
  <a href="resumes.php">Резюме</a>
  <a href="vacancies.php">Вакансии</a>
  <a href="applications.php">Отклики</a>
  <a href="placements.php">Трудоустройства</a>
  <a href="logout.php">Выход</a>
</nav>
<div class="container">
  <h2>Добавить резюме</h2>
  <form method="post">
    <input type="hidden" name="add" value="1">
    Соискатель:
    <select name="seeker_id" required>
      <option value="">-- выберите --</option>
      <?php foreach($seekers as $s): ?>
        <option value="<?=$s["id"]?>"><?=htmlspecialchars($s["fio"])?></option>
      <?php endforeach; ?>
    </select>
    Должность:<input type="text" name="desired_position" required>
    Опыт (лет):<input type="number" name="experience_years">
    Зарплата:<input type="number" step="0.01" name="salary_expectation">
    О себе:<textarea name="about"></textarea>
    <input type="submit" value="Добавить">
  </form>
  <h2>Список резюме</h2>
  <table>
    <tr><th>ID</th><th>Соискатель</th><th>Должность</th><th>Опыт</th><th>Зарплата</th><th>О себе</th><th>Действие</th></tr>
    <?php foreach($resumes as $r): ?>
    <tr>
      <td><?=$r["id"]?></td>
      <td><?=htmlspecialchars($r["fio"])?></td>
      <td><?=htmlspecialchars($r["desired_position"])?></td>
      <td><?=$r["experience_years"]?> лет</td>
      <td><?=$r["salary_expectation"]?></td>
      <td><?=nl2br(htmlspecialchars($r["about"]))?></td>
      <td><a class="delete-btn" href="resumes.php?delete=<?=$r["id"]?>" onclick="return confirm('Удалить резюме?')">Удалить</a></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
</body>
</html>
