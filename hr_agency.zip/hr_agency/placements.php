<?php
session_start();
if (!isset($_SESSION["user_id"])) { header("Location: index.php"); exit; }

$dsn="mysql:host=localhost;dbname=hr_agency;charset=utf8mb4";
$pdo=new PDO($dsn,"root","",[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);

if (isset($_GET["approve"])) {
  $id=(int)$_GET["approve"];
  $stmt=$pdo->prepare("
    SELECT a.id,s.id seeker_id,v.id vacancy_id
    FROM applications a
    JOIN resumes r ON a.resume_id=r.id
    JOIN seekers s ON r.seeker_id=s.id
    JOIN vacancies v ON a.vacancy_id=v.id
    WHERE a.id=?");
  $stmt->execute([$id]);
  if ($row=$stmt->fetch(PDO::FETCH_ASSOC)) {
    $pdo->prepare("INSERT INTO placements(vacancy_id,seeker_id,hired_at) VALUES (?,?,CURDATE())")->execute([$row["vacancy_id"],$row["seeker_id"]]);
    $pdo->prepare("UPDATE seekers SET status='трудоустроен' WHERE id=?")->execute([$row["seeker_id"]]);
    $pdo->prepare("UPDATE vacancies SET status='закрыта' WHERE id=?")->execute([$row["vacancy_id"]]);
    $pdo->prepare("UPDATE applications SET status='одобрен' WHERE id=?")->execute([$id]);
  }
  header("Location: placements.php"); exit;
}

$apps=$pdo->query("
  SELECT a.id,s.fio,v.title,a.status
  FROM applications a
  JOIN resumes r ON a.resume_id=r.id
  JOIN seekers s ON r.seeker_id=s.id
  JOIN vacancies v ON a.vacancy_id=v.id
  WHERE a.status IN('новый','в рассмотрении')
")->fetchAll(PDO::FETCH_ASSOC);

$placements=$pdo->query("
  SELECT p.id,s.fio,v.title,p.hired_at
  FROM placements p
  JOIN seekers s ON p.seeker_id=s.id
  JOIN vacancies v ON p.vacancy_id=v.id
  ORDER BY p.hired_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8"><title>Трудоустройства</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>Модуль "Трудоустройства"</header>
<nav>
  <a href="home.php">Главная</a>
  <a href="seekers.php">Соискатели</a>
  <a href="resumes.php">Резюме</a>
  <a href="vacancies.php">Вакансии</a>
  <a href="applications.php">Отклики</a>
  <a href="placements.php">Трудоустройства</a>
  <a href="logout.php">Выход</a>
</nav>
<div class="container">
  <h2>Отклики для утверждения</h2>
  <?php if (!$apps): ?><p>Нет откликов для утверждения</p><?php endif; ?>
  <table>
    <tr><th>ID</th><th>Соискатель</th><th>Вакансия</th><th>Статус</th><th>Действие</th></tr>
    <?php foreach($apps as $a): ?>
    <tr>
      <td><?=$a["id"]?></td>
      <td><?=htmlspecialchars($a["fio"])?></td>
      <td><?=htmlspecialchars($a["title"])?></td>
      <td><?=$a["status"]?></td>
      <td><a class="approve-btn" href="placements.php?approve=<?=$a["id"]?>" onclick="return confirm('Подтвердить трудоустройство?')">✔ Принять</a></td>
    </tr>
    <?php endforeach; ?>
  </table>

  <h2>История трудоустройств</h2>
  <table>
    <tr><th>ID</th><th>Соискатель</th><th>Вакансия</th><th>Дата</th></tr>
    <?php foreach($placements as $p): ?>
    <tr>
      <td><?=$p["id"]?></td>
      <td><?=htmlspecialchars($p["fio"])?></td>
      <td><?=htmlspecialchars($p["title"])?></td>
      <td><?=$p["hired_at"]?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
</body>
</html>
