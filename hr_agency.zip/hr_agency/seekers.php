<?php
session_start();
if (!isset($_SESSION["user_id"])) { header("Location: index.php"); exit; }

$dsn = "mysql:host=localhost;dbname=hr_agency;charset=utf8mb4";
$pdo = new PDO($dsn, "root", "", [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);

if ($_SERVER["REQUEST_METHOD"]==="POST" && isset($_POST["add"])) {
  $stmt=$pdo->prepare("INSERT INTO seekers(fio,birthdate,phone,email) VALUES (?,?,?,?)");
  $stmt->execute([$_POST["fio"],$_POST["birthdate"],$_POST["phone"],$_POST["email"]]);
  header("Location: seekers.php"); exit;
}
if (isset($_GET["delete"])) {
  $pdo->prepare("DELETE FROM seekers WHERE id=?")->execute([$_GET["delete"]]);
  header("Location: seekers.php"); exit;
}
$seekers=$pdo->query("SELECT * FROM seekers ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8"><title>Соискатели</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>Модуль "Соискатели"</header>
<nav>
  <a href="home.php">Главная</a>
  <a href="seekers.php">Соискатели</a>
  <a href="resumes.php">Резюме</a>
  <a href="vacancies.php">Вакансии</a>
  <a href="applications.php">Отклики</a>
  <a href="placements.php">Трудоустройства</a>
  <a href="logout.php">Выход</a>
</nav>
<div class="container">
  <h2>Добавить соискателя</h2>
  <form method="post">
    <input type="hidden" name="add" value="1">
    ФИО:<input type="text" name="fio" required>
    Дата рождения:<input type="date" name="birthdate">
    Телефон:<input type="text" name="phone">
    Email:<input type="email" name="email">
    <input type="submit" value="Добавить">
  </form>
  <h2>Список соискателей</h2>
  <table>
    <tr><th>ID</th><th>ФИО</th><th>Дата рождения</th><th>Телефон</th><th>Email</th><th>Статус</th><th>Действие</th></tr>
    <?php foreach($seekers as $s): ?>
    <tr>
      <td><?=$s["id"]?></td>
      <td><?=htmlspecialchars($s["fio"])?></td>
      <td><?=$s["birthdate"]?></td>
      <td><?=htmlspecialchars($s["phone"])?></td>
      <td><?=htmlspecialchars($s["email"])?></td>
      <td><?=$s["status"]?></td>
      <td><a class="delete-btn" href="seekers.php?delete=<?=$s["id"]?>" onclick="return confirm('Удалить?')">Удалить</a></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
</body>
</html>
